from setuptools import setup, find_packages

setup(name='modulemlem',
      description='module for exercise',
      author='Matteo Colombo',
      author_email='m.colombo279@campus.unimib.it',
      version='0.0.2',
      packages=find_packages(),
      install_requires=['numpy', 'matplotlib','scipy'])